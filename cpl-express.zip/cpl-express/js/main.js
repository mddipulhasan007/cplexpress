//Service Slider
$('.service_slider').slick({
    dots: false,
    infinite: true,
    speed: 300,
    slidesToShow: 6,
    slidesToScroll: 1,
    arrows: true,
    prevArrow: "<button type='button' class='slick-prev pull-left'><i class='fa fa-angle-left' aria-hidden='true'></i></button>",
    nextArrow: "<button type='button' class='slick-next pull-right'><i class='fa fa-angle-right' aria-hidden='true'></i></button>",
    autoplay: true,
    pauseOnHover: true,
    responsive: [
        {
            breakpoint: 1024,
            settings: {
                slidesToShow: 4,
                slidesToScroll: 1,
                infinite: true,
                dots: false
            }
        },
        {
            breakpoint: 600,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1
            }
        },
        {
            breakpoint: 480,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }
        // You can unslick at a given breakpoint now by adding:
        // settings: "unslick"
        // instead of a settings object
    ]
});















/*
practice carosal concept using slick slider
for working perfectly add slick.js and slick.css 
file to your project folder
*/


/*--------------------------------
    Testimonial Slick Carousel .testimonial-text-slider .testimonial-image-slider
-----------------------------------*/
$('.slider-for').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    draggable: false,
    fade: true,
    asNavFor: '.slider-nav'
});
/*------------------------------------
Testimonial Slick Carousel as Nav
--------------------------------------*/
$('.slider-nav').slick({
    slidesToShow: 3,
    slidesToScroll: 1,
    asNavFor: '.slider-for',
    dots: false,
    arrows: true,
    centerMode: true,
    focusOnSelect: true,
    centerPadding: '10px',
    autoplay: true,
    responsive: [
        {
            breakpoint: 450,
            settings: {
                dots: false,
                slidesToShow: 3,
                centerPadding: '0px',
            }
        },
        {
            breakpoint: 420,
            settings: {
                autoplay: true,
                dots: false,
                slidesToShow: 1,
                centerMode: false,
            }
        }
    ]
});


// Counter Section
$('.counter').counterUp({
    delay: 10,
    time: 1000
});

//scroll to top
$(window).scroll(function () {
    if ($(this).scrollTop() >= 150) {
        $('.back_to_top_wrap:hidden').stop(true, true).fadeIn();
    } else {
        $('.back_to_top_wrap').stop(true, true).fadeOut();
    }
});
$(function () { $(".back_top_icon").click(function () { $("html,body").animate({ scrollTop: $(".top_header_wrapper").offset().top }, "1000"); return false }) })